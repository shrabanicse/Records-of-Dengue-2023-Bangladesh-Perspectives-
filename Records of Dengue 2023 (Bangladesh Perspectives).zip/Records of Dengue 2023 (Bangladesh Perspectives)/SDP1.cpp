#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<dos.h>
#include<conio.h>
#include<fstream>
#include<ostream>
#include<windows.h>
using namespace std;
int main();
void main_menu();
void show();
void returnm();
void returnmenu();
void initiatives();
void symptoms();
void remedy();
void prevention();
void records_panel();
void dengue_records();
void admin_dengue_records();
void July2023();
void August2023();
void September2023();
void October2023();
void November2023();
void hospital_information();
void donners_list();
void change();
void Admin();
void instruction();
void July_2023();
void August_2023();
void September_2023();
void October_2023();
void November_2023();
int P=1;
void loadingBar()
{
    system("color B5");
    char a = 177, b = 219;
    cout << "\n\n\n\t\t\t\t";
    cout << "\n\n\n\n\n\t\t\t\t\t\t\t" " Loading..\n\n";
    cout << "\t\t\t\t\t\t\t";
    for (int i = 0; i < 12; i++)
    {
        printf("%c", a);
    }
    cout << "\r";
    cout << "\t\t\t\t\t\t\t";
    for (int i = 0; i < 12; i++)
    {
        printf("%c", b);
        Sleep(150);
    }
}
void main_menu()
{
    system("cls");
    system("COLOR  D0");
    int w;
    cout<<"\n\n\n\n\t\t\t\t\t\t  ..................."<<endl;
    cout<<"\t\t\t\t\t\t    ~  Main Menu  ~"<<endl;
    cout<<"\t\t\t\t\t\t  ..................."<<endl;
    cout<<"\n\n\n\t\t\t\t\t\t 1. About Dengue\n";
    cout<<"\n\t\t\t\t\t\t 2. Records of Dengue in BD\n";
    cout<<"\n\t\t\t\t\t\t 3. Blood Donner's List\n";
    cout<<"\n\t\t\t\t\t\t 4. Admin Panel\n";
    cout<<"\n\t\t\t\t\t\t Enter Your Choice: ";
    scanf("%d",&w);
    switch(w)
    {
    case 1:
    {
        initiatives();
        break;
    }
    case 2:
    {
        records_panel();
        break;
    }
    case 3:
    {
        donners_list();
        break;
    }
    case 4:
    {
        Admin();
        break;
    }
    default :
    {
        main_menu();
        break;
    }
    }
}
void change()
{
    system("cls");
    system("color CE");
    cout<<"\n\n\n\n\t\t\t\t\t\t  ......................"<<endl;
    cout<<"\t\t\t\t\t\t    ~  Change Panel  ~"<<endl;
    cout<<"\t\t\t\t\t\t  ......................"<<endl;
    cout << "\n\t\t\t\t\t\t 1. Dengue Records of BD\n";
    cout << "\n\t\t\t\t\t\t 2. Back to the Main Menu\n";
    cout << "\n\t\t\t\t\t\t 0. Log Out\n";
    cout << "\n\t\t\t\t\t Enter Your Choice: ";
    show();
}
void show()
{
    int n;
    cin >> n;
    switch(n)
    {
    case 0:
    {
        exit(0);
        break;
    }
    case 1:
    {
        admin_dengue_records();
    }
    case 2:
    {
        main_menu();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        show();
    }
    }
}
void Admin()
{
    system("cls");
    system("color 0F");
    string u,p,s;
    char user[10];
    cout<<"\n\n\n\n\t\t\t\t\t\t  ....................."<<endl;
    cout<<"\t\t\t\t\t\t    ~  Admin Panel  ~"<<endl;
    cout<<"\t\t\t\t\t\t  ....................."<<endl;
    cout<<"\n\n\t\t\t\t\t Enter Username    : ";
    cin>>user;
    char pass[10],pa;
    int j;
    cout<<"\t\t\t\t\t Enter Password    : ";
    for(j = 0; j < 100; j++)
    {
        pa = getch();
        if(pa == 13)
            break;
        pass[j] = pa;
        pa = '*' ;
        printf("%c", pa);
    }
    pass[j] = '\0';
    cout<<"\n\t\t\t\t\t Enter Unique Code : ";
    char uniq[10],un;
    int k;
    for(k = 0; k < 100; k++)
    {
        un = getch();
        if(un == 13)
            break;
        uniq[k] = un;
        un = '*' ;
        printf("%c", un);
    }
    uniq[k] = '\0';
    cout << endl;
    ifstream input("Admin.txt");
    while(input>>u>>p>>s)
    {
        if(u == user && p == pass && s==uniq)
        {
            cout << "\n\n\t\t\t\t\tYour Information is Correct !"<<endl;
            cout << endl;
            cout << endl;
            system("pause");
            change();
            break;
        }
        else
        {
            if(P==3)
            {
                exit(0);
            }
            printf("\n\n\t\t\t\t\t Username/Password/Unique Code is wrong %d to 3 !",P);
            cout<<"\n\n\t\t\t\t\t Try Again.."<<endl;
            P++;
            cout<<endl;
            cout<<endl;
            system("pause");
            Admin();
        }
    }
}
void donners_list()
{
    system ("cls");
    system("COLOR E0");
    int n;
    std :: string line;
    ifstream file("E:\\10th Semester\\CSE 100\\Donners_list.txt");
    while(getline(file,line))
    {
        std :: cout <<line<<'\n';
    }
    file.close();
    cout<<"\n\n\n\t\t\t\t\t Press Enter to Back to the Main Menu ! \n";
    fflush(stdin);
    getchar();
    main_menu();
}
void initiatives()
{
    system ("cls");
    int p;
    system("COLOR  F1");
    cout<<"\n\n\n\n\t\t\t\t\t\t  ............................"<<endl;
    cout<<"\t\t\t\t\t\t    ~  Dengue Initiatives  ~"<<endl;
    cout<<"\t\t\t\t\t\t  ............................"<<endl;
    cout << "\n\n\n\t\t\t\t\t\t 1. Symptoms of Dengue\n";
    cout << "\n\t\t\t\t\t\t 2. Remedy from Dengue\n";
    cout << "\n\t\t\t\t\t\t 3. Prevention of Dengue\n";
    cout << "\n\t\t\t\t\t\t 4. Back to the Main Menu\n";
    cout << "\n\t\t\t\t\t\t 0. Exit\n";
    cout << "\n\t\t\t\t\t\t Enter Your Choice: ";
    scanf("%d",&p);
    switch(p)
    {
    case 0:
    {
        exit(0);
        break;
    }
    case 1:
    {
        symptoms();
        break;
    }
    case 2:
    {
        remedy();
        break;
    }
    case 3:
    {
        prevention();
        break;
    }
    case 4:
    {
        main_menu();
        break;
    }
    default:
    {
        system("cls");
        printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t Entered Wrong Data !");
        printf("\n\n\t\t\t\t\t You can go to the Dengue Initiatives part by pressing Enter !\n\n\n");
        fflush(stdin);
        getchar();
        initiatives();
    }
    }
}
void symptoms()
{
    system ("cls");
    system("color B0");
    int n;
    std :: string line;
    ifstream file("E:\\10th Semester\\CSE 100\\Symptoms.txt");
    while(getline(file,line))
    {
        std :: cout <<line<<'\n';
    }
    file.close();
    returnm();
}
void remedy()
{
    system ("cls");
    system("color C0");
    int n;
    std :: string line;
    ifstream file("E:\\10th Semester\\CSE 100\\Remedy.txt");
    while(getline(file,line))
    {
        std :: cout <<line<<'\n';
    }
    file.close();
    returnm();
}
void prevention()
{
    system ("cls");
    system("color E0");
    int n;
    std :: string line;
    ifstream file("E:\\10th Semester\\CSE 100\\Prevention.txt");
    while(getline(file,line))
    {
        std :: cout <<line<<'\n';
    }
    file.close();
    returnm();
}
void records_panel()
{
    system("cls");
    system("COLOR 9F");
    cout<< "\n\n\t\t\t\t\t\t    .....................\n";
    cout<< "\t\t\t\t\t\t     ~  Records Panel  ~ \n";
    cout<< "\t\t\t\t\t\t    .....................\n\n\n";
    cout<< "\t\t\t\t\t\t 1. Hospitals Information\n\n";
    cout<< "\t\t\t\t\t\t 2. Dengue Records of BD\n\n";
    cout<< "\t\t\t\t\t\t 3. Back to the Main Menu\n\n";
    cout<< "\t\t\t\t\t\t 0. Exit\n";
    cout<< "\n\t\t\t\t\t\t Enter Your Choice: ";
    int k;
    scanf("%d",&k);
    switch(k)
    {
    case 0:
    {
        exit(0);
        break;
    }
    case 1:
    {
        hospital_information();
        fflush(stdin);
        getchar();
        break;
    }
    case 2:
    {
        dengue_records();
        fflush(stdin);
        getchar();
        break;
    }
    case 3:
    {
        main_menu();
        fflush(stdin);
        getchar();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        fflush(stdin);
        getchar();
        main();
        break;
    }
    }
}
void  hospital_information()
{
    system ("cls");
    system("COLOR  5F");
    int n;
    FILE *fp;
    fp = fopen("E:\\10th Semester\\CSE 100\\Hospital_Information.txt","r");
    char ch[1000001];
    while(fgets(ch,sizeof(ch),fp))
    {
        printf("%s",ch);
    }
    fclose(fp);
    cout<<"\n\n\n\t\t\t\t\t Press 1 to Back to the Records Panel ! \n";
    cout<<"\t\t\t\t\t Press O to Exit ! \n";
    cout<<"\t\t\t\t\t Enter Your Choice: ";
    scanf("%d", &n);
    switch(n)
    {
    case 0:
    {
        exit(0);
        break;
    }
    case 1:
    {
        records_panel();
        fflush(stdin);
        getchar();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        fflush(stdin);
        getchar();
        initiatives();
    }
    }
}
void dengue_records()
{
    system ("cls");
    int choice;
    system("COLOR  B0");
    cout << "\n\n\n\t\t\t ~~ Records of Dengue in Bangladesh from July 2023 to November 2023 ~~\n\n\n";
    cout << "\n\t\t\t\t\t\t 1. July 2023\n";
    cout << "\n\t\t\t\t\t\t 2. August 2023\n";
    cout << "\n\t\t\t\t\t\t 3. September 2023\n";
    cout << "\n\t\t\t\t\t\t 4. October 2023\n";
    cout << "\n\t\t\t\t\t\t 5. November 2023\n";
    cout << "\n\t\t\t\t\t\t 6. Back to the Records Panel\n";
    cout << "\n\t\t\t\t\t\t 0. Exit\n";
    cout << "\n\t\t\t\t\t\t Enter Your Choice: ";
    scanf("%d", &choice);
    switch(choice)
    {
    case 0:
    {
        exit(0);
        break;
    }
    case 1:
    {
        July2023();
        break;
    }
    case 2:
    {
        August2023();
        break;
    }
    case 3:
    {
        September2023();
        break;
    }
    case 4:
    {
        October2023();
        break;
    }
    case 5:
    {
        November2023();
        break;
    }
    case 6:
    {
        records_panel();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        fflush(stdin);
        getchar();
        system("cls");
        dengue_records();
        break;
    }
    }
}
void admin_dengue_records()
{
    system ("cls");
    int choice;
    system("COLOR ED");
    cout<<"\n\n\n\n\t\t\t\t\t\t  ....................."<<endl;
    cout<<"\t\t\t\t\t\t    ~  Admin Panel  ~"<<endl;
    cout<<"\t\t\t\t\t\t  ....................."<<endl;
    cout << "\n\n\t\t\t ~~ Records of Dengue in Bangladesh from July 2023 to November 2023 ~~\n\n";
    cout << "\n\n\t\t\t\t\t\t 1. July 2023\n";
    cout << "\n\t\t\t\t\t\t 2. August 2023\n";
    cout << "\n\t\t\t\t\t\t 3. September 2023\n";
    cout << "\n\t\t\t\t\t\t 4. October 2023\n";
    cout << "\n\t\t\t\t\t\t 5. November 2023\n";
    cout << "\n\t\t\t\t\t\t 6. Back to the Change Panel\n";
    cout << "\n\t\t\t\t\t\t 0. Exit\n";
    cout << "\n\t\t\t\t\t\t Enter Your Choice: ";
    scanf("%d", &choice);
    switch(choice)
    {
    case 0:
    {
        exit(0);
        break;
    }
    case 1:
    {
        July_2023();
        break;
    }
    case 2:
    {
        August_2023();
        break;
    }
    case 3:
    {
        September_2023();
        break;
    }
    case 4:
    {
        October_2023();
        break;
    }
    case 5:
    {
        November_2023();
        break;
    }
    case 6:
    {
        system("cls");
        change();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        fflush(stdin);
        getchar();
        system("cls");
        admin_dengue_records();
        break;
    }
    }
}
void July_2023()
{
    system("cls");
    system("color 30");
    int n;
    string line1,line2,line3,line4,line5,line6,line7,line8,line9,line10,line11;
    fstream file;
    file.open("E:\\10th Semester\\CSE 100\\July2023.txt",ios::in);
    getline(file,line1);
    getline(file,line2);
    getline(file,line3);
    getline(file,line4);
    getline(file,line5);
    getline(file,line6);
    getline(file,line7);
    getline(file,line8);
    getline(file,line9);
    getline(file,line10);
    getline(file,line11);
    file.close();
    cout<<"\t"<<line1<<endl<<"\t"<<line2<<endl<<"\t"<<line3<<endl<<"\t"<<line4<<endl<<"\t"<<line5<<endl<<"\t"<<line6<<endl<<"\t"<<line7<<endl<<"\t"<<line8<<endl<<"\t"<<line9<<endl<<"\t"<<line10<<endl<<"\t"<<line11<<endl;
    cout<<"\n\tPress 1/2/3 to Change Any Data: ";
    cin>>n;
    cin.ignore();
    if(n==1)
    {
        cout<< "\tAffected: ";
        getline(cin,line3);
    }
    if(n==2)
    {
        cout<< "\tDeath: ";
        getline(cin,line7);
    }
    if(n==3)
    {
        cout<< "\tRecovered: ";
        getline(cin,line11);
    }
    ofstream file2;
    file2.open("E:\\10th Semester\\CSE 100\\July2023.txt");
    file2<<line1<<endl<<line2<<endl<<line3<<endl<<line4<<endl<<line5<<endl<<line6<<endl<<line7<<endl<<line8<<endl<<line9<<endl<<line10<<endl<<line11<<endl;
    file2.close();
    cout<<endl<<endl;
    string name;
    ifstream read("E:\\10th Semester\\CSE 100\\July2023.txt");
    while(getline(read,name))
    {
        cout<< "\t";
        cout<<name<<endl;
    }
    cout << "\t\t\t\t\t\t  ~~ Press Enter to Back to the Admin Panel ~~\n";
    fflush(stdin);
    getchar();
    read.close();
    admin_dengue_records();
}
void August_2023()
{
    system("cls");
    system("color 40");
    int n;
    string line1,line2,line3,line4,line5,line6,line7,line8,line9,line10,line11;
    fstream file;
    file.open("E:\\10th Semester\\CSE 100\\August2023.txt",ios::in);
    getline(file,line1);
    getline(file,line2);
    getline(file,line3);
    getline(file,line4);
    getline(file,line5);
    getline(file,line6);
    getline(file,line7);
    getline(file,line8);
    getline(file,line9);
    getline(file,line10);
    getline(file,line11);
    file.close();
    cout<<"\t"<<line1<<endl<<"\t"<<line2<<endl<<"\t"<<line3<<endl<<"\t"<<line4<<endl<<"\t"<<line5<<endl<<"\t"<<line6<<endl<<"\t"<<line7<<endl<<"\t"<<line8<<endl<<"\t"<<line9<<endl<<"\t"<<line10<<endl<<"\t"<<line11<<endl;
    cout<<"\n\tPress 1/2/3 to Change Any Data: ";
    cin>>n;
    cin.ignore();
    if(n==1)
    {
        cout<< "\tAffected: ";
        getline(cin,line3);
    }
    if(n==2)
    {
        cout<< "\tDeath: ";
        getline(cin,line7);
    }
    if(n==3)
    {
        cout<< "\tRecovered: ";
        getline(cin,line11);
    }
    ofstream file2;
    file2.open("E:\\10th Semester\\CSE 100\\August2023.txt");
    file2<<line1<<endl<<line2<<endl<<line3<<endl<<line4<<endl<<line5<<endl<<line6<<endl<<line7<<endl<<line8<<endl<<line9<<endl<<line10<<endl<<line11<<endl;
    file2.close();
    cout<<endl<<endl;
    string name;
    ifstream read("E:\\10th Semester\\CSE 100\\August2023.txt");
    while(getline(read,name))
    {
        cout<< "\t";
        cout<<name<<endl;
    }
    cout << "\t\t\t\t\t\t  ~~ Press Enter to Back to the Admin Panel ~~\n";
    fflush(stdin);
    getchar();
    read.close();
    admin_dengue_records();
}
void September_2023()
{
    system("cls");
    system("color 50");
    int n;
    string line1,line2,line3,line4,line5,line6,line7,line8,line9,line10,line11;
    fstream file;
    file.open("E:\\10th Semester\\CSE 100\\September2023.txt",ios::in);
    getline(file,line1);
    getline(file,line2);
    getline(file,line3);
    getline(file,line4);
    getline(file,line5);
    getline(file,line6);
    getline(file,line7);
    getline(file,line8);
    getline(file,line9);
    getline(file,line10);
    getline(file,line11);
    file.close();
    cout<<"\t"<<line1<<endl<<"\t"<<line2<<endl<<"\t"<<line3<<endl<<"\t"<<line4<<endl<<"\t"<<line5<<endl<<"\t"<<line6<<endl<<"\t"<<line7<<endl<<"\t"<<line8<<endl<<"\t"<<line9<<endl<<"\t"<<line10<<endl<<"\t"<<line11<<endl;
    cout<<"\n\tPress 1/2/3 to Change Any Data: ";
    cin>>n;
    cin.ignore();
    if(n==1)
    {
        cout<< "\tAffected: ";
        getline(cin,line3);
    }
    if(n==2)
    {
        cout<< "\tDeath: ";
        getline(cin,line7);
    }
    if(n==3)
    {
        cout<< "\tRecovered: ";
        getline(cin,line11);
    }
    ofstream file2;
    file2.open("E:\\10th Semester\\CSE 100\\September.txt");
    file2<<line1<<endl<<line2<<endl<<line3<<endl<<line4<<endl<<line5<<endl<<line6<<endl<<line7<<endl<<line8<<endl<<line9<<endl<<line10<<endl<<line11<<endl;
    file2.close();
    cout<<endl<<endl;
    string name;
    ifstream read("E:\\10th Semester\\CSE 100\\September2023.txt");
    while(getline(read,name))
    {
        cout<< "\t";
        cout<<name<<endl;
    }
    cout << "\t\t\t\t\t\t  ~~ Press Enter to Back to the Admin Panel ~~\n";
    fflush(stdin);
    getchar();
    read.close();
    admin_dengue_records();
}
void October_2023()
{
    system("cls");
    system("color 60");
    int n;
    string line1,line2,line3,line4,line5,line6,line7,line8,line9,line10,line11;
    fstream file;
    file.open("E:\\10th Semester\\CSE 100\\October2023.txt",ios::in);
    getline(file,line1);
    getline(file,line2);
    getline(file,line3);
    getline(file,line4);
    getline(file,line5);
    getline(file,line6);
    getline(file,line7);
    getline(file,line8);
    getline(file,line9);
    getline(file,line10);
    getline(file,line11);
    file.close();
    cout<<"\t"<<line1<<endl<<"\t"<<line2<<endl<<"\t"<<line3<<endl<<"\t"<<line4<<endl<<"\t"<<line5<<endl<<"\t"<<line6<<endl<<"\t"<<line7<<endl<<"\t"<<line8<<endl<<"\t"<<line9<<endl<<"\t"<<line10<<endl<<"\t"<<line11<<endl;
    cout<<"\n\tPress 1/2/3 to Change Any Data: ";
    cin>>n;
    cin.ignore();
    if(n==1)
    {
        cout<< "\tAffected: ";
        getline(cin,line3);
    }
    if(n==2)
    {
        cout<< "\tDeath: ";
        getline(cin,line7);
    }
    if(n==3)
    {
        cout<< "\tRecovered: ";
        getline(cin,line11);
    }
    ofstream file2;
    file2.open("E:\\10th Semester\\CSE 100\\October2023.txt");
    file2<<line1<<endl<<line2<<endl<<line3<<endl<<line4<<endl<<line5<<endl<<line6<<endl<<line7<<endl<<line8<<endl<<line9<<endl<<line10<<endl<<line11<<endl;
    file2.close();
    cout<<endl<<endl;
    string name;
    ifstream read("E:\\10th Semester\\CSE 100\\October2023.txt");
    while(getline(read,name))
    {
        cout<< "\t";
        cout<<name<<endl;
    }
    cout << "\t\t\t\t\t\t  ~~ Press Enter to Back to the Admin Panel ~~\n";
    fflush(stdin);
    getchar();
    read.close();
    admin_dengue_records();
}
void November_2023()
{
    system("cls");
    system("color 70");
    int n;
    string line1,line2,line3,line4,line5,line6,line7,line8,line9,line10,line11;
    fstream file;
    file.open("E:\\10th Semester\\CSE 100\\November2023.txt",ios::in);
    getline(file,line1);
    getline(file,line2);
    getline(file,line3);
    getline(file,line4);
    getline(file,line5);
    getline(file,line6);
    getline(file,line7);
    getline(file,line8);
    getline(file,line9);
    getline(file,line10);
    getline(file,line11);
    file.close();
    cout<<"\t"<<line1<<endl<<"\t"<<line2<<endl<<"\t"<<line3<<endl<<"\t"<<line4<<endl<<"\t"<<line5<<endl<<"\t"<<line6<<endl<<"\t"<<line7<<endl<<"\t"<<line8<<endl<<"\t"<<line9<<endl<<"\t"<<line10<<endl<<"\t"<<line11<<endl;
    cout<<"\n\tPress 1/2/3 to Change Any Data: ";
    cin>>n;
    cin.ignore();
    if(n==1)
    {
        cout<< "\tAffected: ";
        getline(cin,line3);
    }
    if(n==2)
    {
        cout<< "\tDeath: ";
        getline(cin,line7);
    }
    if(n==3)
    {
        cout<< "\tRecovered: ";
        getline(cin,line11);
    }
    ofstream file2;
    file2.open("E:\\10th Semester\\CSE 100\\November2023.txt");
    file2<<line1<<endl<<line2<<endl<<line3<<endl<<line4<<endl<<line5<<endl<<line6<<endl<<line7<<endl<<line8<<endl<<line9<<endl<<line10<<endl<<line11<<endl;
    file2.close();
    cout<<endl<<endl;
    string name;
    ifstream read("E:\\10th Semester\\CSE 100\\November2023.txt");
    while(getline(read,name))
    {
        cout<< "\t";
        cout<<name<<endl;
    }
    cout << "\t\t\t\t\t\t  ~~ Press Enter to Back to the Admin Panel ~~\n";
    fflush(stdin);
    getchar();
    read.close();
    admin_dengue_records();
}
void July2023()
{
    system ("cls");
    system("color E5");
    int n;
    std :: string line_;
    ifstream file_("E:\\10th Semester\\CSE 100\\July2023.txt");
    while(getline(file_,line_))
    {
        std :: cout <<line_<<'\n';
    }
    file_.close();
    returnmenu();
}
void August2023()
{
    system ("cls");
    system("color 5B");
    int n;
    std :: string line_;
    ifstream file_("E:\\10th Semester\\CSE 100\\August2023.txt");
    while(getline(file_,line_))
    {
        std :: cout <<line_<<'\n';
    }
    file_.close();
    returnmenu();
}
void September2023()
{
    system ("cls");
    system("color 7C");
    int n;
    std :: string line_;
    ifstream file_("E:\\10th Semester\\CSE 100\\September2023.txt");
    while(getline(file_,line_))
    {
        std :: cout <<line_<<'\n';
    }
    file_.close();
    returnmenu();
}
void October2023()
{
    system ("cls");
    system("color 6F");
    int n;
    std :: string line_;
    ifstream file_("E:\\10th Semester\\CSE 100\\October2023.txt");
    while(getline(file_,line_))
    {
        std :: cout <<line_<<'\n';
    }
    file_.close();
    returnmenu();
}
void November2023()
{
    system ("cls");
    system("color 5E");
    int n;
    std :: string line_;
    ifstream file_("E:\\10th Semester\\CSE 100\\November2023.txt");
    while(getline(file_,line_))
    {
        std :: cout <<line_<<'\n';
    }
    file_.close();
    returnmenu();
}
void returnmenu()
{
    int n;
    cout<< "\n\n\t\t\t\t\t Press 1 to Back to the Main Menu ! \n\n";
    cout<< "\t\t\t\t\t Press 2 to Back to the Records of Dengue ! \n\n";
    cout<< "\t\t\t\t\t Press Key: ";
    cin>>n;
    switch(n)
    {
    case 1:
    {
        main_menu();
        break;
    }
    case 2:
    {
        dengue_records();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        system("pause");
        dengue_records();
    }
    }
}
void returnm()
{
    int n;
    cout<< "\n\n\t\t\t\t\t Press 1 to Back to the Main Menu ! \n\n";
    cout<< "\t\t\t\t\t Press 2 to Back to the Dengue Initiatives ! \n\n";
    cout<< "\t\t\t\t\t Press Key: ";
    cin>>n;
    switch(n)
    {
    case 1:
    {
        main_menu();
        break;
    }
    case 2:
    {
        initiatives();
        break;
    }
    default:
    {
        printf("\n\n\t\t Your Choice is Wrong ! \n\t\t Try Again..\n");
        system("pause");
        dengue_records();
    }
    }
}
int main()
{
    cout<< "\n\n\n\n\n\n\n\n\t\t\t\t------------------------------------------------------------\n\t\t\t";
    cout<< "\n\t\t\t\t ~~  Records of Dengue 2023 (Bangladesh Perspectives)  ~~\n\t\t";
    cout<< "\n\t\t\t\t------------------------------------------------------------\n";
    system("color 9F");
    loadingBar();
    instruction();
}
void instruction()
{
    system("cls");
    system("color F9");
    cout<<"\n\n\n\n\n\t# In this project of 'Records of Dengue 2023 (Bangladesh Perspectives)' represents an overview of Dengue, such as: "<<endl;
    cout <<"\n\t\t 1. Total Infected People 2. Total Death & 3. Total Recovered people all over Bangladesh from July 2023 to November 2023."<<endl;
    cout<<"\n\t# Additionally, here includes: \n\n\t\t 1. Symptoms of Dengue, 2. Remedy from Dengue and 3. Prevention of Dengue."<<endl;
    cout<<"\n\t# Also, there is a list of hospitals that serve Dengue patients."<<endl;
    cout<<"\n\t# Here, viewers can have a look at the Blood Donner's list."<<endl;
    cout<<"\n\t# An Admin Panel where Admins can Login to the system and able to change the data."<<endl;
    cout<<"\n\n\n\n\n";
    system("pause");
    main_menu();
}
